module FFI
  VERSION = '1.16.3'
end
